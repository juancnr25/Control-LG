# Remoto LG (32LM630BPSB)

App Android híbrida para el TV LG 32LM630BPSB (webOS 4.5):

- **IR** (emisor del celular, protocolo NEC, dirección 0x04): encender el TV y respaldo de todos los botones.
- **Wi-Fi** (protocolo SSAP de webOS, puertos 3001/3000): botones sin apuntar, puntero tipo Magic Remote, lista de apps y entradas, teclado en vivo y lectura de volumen.

## Compilar el APK con GitHub Actions

1. Crea un repositorio nuevo en GitHub (privado recomendado).
2. Sube **todo** el contenido de esta carpeta, incluida la carpeta oculta `.github`.
   Con git: `git init && git add . && git commit -m "Remoto LG" && git branch -M main && git remote add origin <URL> && git push -u origin main`
3. Entra a la pestaña **Actions**: el flujo "Compilar APK" tarda unos 3 a 4 minutos.
4. Al terminar, el APK aparece en **Releases** como `RemotoLG.apk`. Ábrelo desde el celular e instálalo (Android pedirá permitir apps de origen desconocido para tu navegador).

Cada push genera una versión nueva. El keystore fijo (`app/remoto.keystore`) permite instalar encima sin desinstalar.

## Primera conexión Wi-Fi

1. TV y celular en la misma red.
2. En el TV, activa **LG Connect Apps** (configuración de red o de conexión).
3. En la app toca el estado de arriba a la derecha › **Buscar** › **Conectar**.
4. El TV muestra una solicitud: acéptala con la flecha y OK de la app (salen por IR).

La app guarda la clave de emparejamiento y fija la huella del certificado del TV. Si actualizas el firmware del TV y deja de conectar, usa **Olvidar TV** y empareja de nuevo.

## Estructura

| Archivo | Función |
|---|---|
| `IrBlaster.java` | Tramas NEC 38 kHz por `ConsumerIrManager` |
| `WsClient.java` | Cliente WebSocket sin dependencias (ws y wss con TOFU) |
| `LgTv.java` | Registro SSAP, canal de puntero, solicitudes |
| `Descubrimiento.java` | Búsqueda del TV por SSDP |
| `MainActivity.java` | WebView + puente `Native` + botones de volumen físicos |
| `assets/index.html` | Interfaz completa |
