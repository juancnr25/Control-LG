package pe.jc.remotolg;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Control del TV por Wi-Fi con el protocolo SSAP de webOS.
 * Canal principal (puerto 3001 wss o 3000 ws): registro, apps, volumen, texto.
 * Canal de puntero: botones del control, cursor, clic y desplazamiento.
 */
final class LgTv {

    interface Eventos {
        void onEstadoTv(String json);

        void onRespuestaTv(String id, String json);
    }

    private static final int TIMEOUT_MS = 2500;

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Eventos eventos;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private volatile WsClient principal;
    private volatile WsClient puntero;
    private volatile String estado = "desconectado";
    private volatile String detalle = "";
    private volatile String ip;
    private volatile int generacion = 0;
    private volatile String huellaPendiente;
    private volatile boolean reintentoSinClave;
    private volatile long ultimoPedidoPuntero;

    LgTv(Context ctx, SharedPreferences prefs, Eventos eventos) {
        this.ctx = ctx.getApplicationContext();
        this.prefs = prefs;
        this.eventos = eventos;
        this.ip = prefs.getString("ip", "");
    }

    // ---------- API pública ----------

    synchronized void conectar(String host) {
        final int gen = ++generacion;
        final String h = host == null ? "" : host.trim();
        io.execute(() -> hacerConexion(h, gen));
    }

    synchronized void desconectar() {
        generacion++;
        io.execute(this::cerrarSockets);
        fijarEstado("desconectado", "");
    }

    void olvidar() {
        desconectar();
        prefs.edit().remove("clientKey").remove("certPin").apply();
    }

    String estadoJson() {
        try {
            WsClient p = puntero;
            return new JSONObject()
                    .put("estado", estado)
                    .put("detalle", detalle)
                    .put("ip", ip == null ? "" : ip)
                    .put("puntero", p != null && p.estaAbierto())
                    .put("emparejado", prefs.getString("clientKey", null) != null)
                    .toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    boolean boton(String nombre) {
        return enviarPuntero("type:button\nname:" + nombre + "\n\n");
    }

    boolean mover(int dx, int dy) {
        return enviarPuntero("type:move\ndx:" + dx + "\ndy:" + dy + "\ndown:0\n\n");
    }

    boolean clic() {
        return enviarPuntero("type:click\n\n");
    }

    boolean desplazar(int dy) {
        return enviarPuntero("type:scroll\ndx:0\ndy:" + dy + "\n\n");
    }

    boolean solicitar(String idJs, String uri, String payload) {
        WsClient c = principal;
        if (c == null || !c.estaAbierto() || !"conectado".equals(estado)) return false;
        try {
            JSONObject m = new JSONObject()
                    .put("type", "request")
                    .put("id", "js:" + idJs)
                    .put("uri", uri);
            if (payload != null && !payload.isEmpty()) m.put("payload", new JSONObject(payload));
            c.enviarTexto(m.toString());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- Conexión ----------

    private void hacerConexion(String host, int gen) {
        cerrarSockets();
        if (host.isEmpty()) {
            fijarEstado("error", "Escribe la IP del TV");
            return;
        }
        ip = host;
        prefs.edit().putString("ip", host).apply();
        fijarEstado("conectando", host);

        String pin = prefs.getString("certPin", null);
        WsClient c = null;
        String error = null;
        try {
            c = abrirPrincipal(host, 3001, true, pin, gen);
        } catch (IOException e) {
            error = e.getMessage();
        }
        boolean errorDeCertificado = error != null && error.startsWith("CERT");
        if (c == null && !errorDeCertificado) {
            try {
                c = abrirPrincipal(host, 3000, false, null, gen);
                error = null;
            } catch (IOException e) {
                if (error == null) error = e.getMessage();
            }
        }
        if (gen != generacion) {
            if (c != null) c.cerrar();
            return;
        }
        if (c == null) {
            fijarEstado("error", errorDeCertificado ? error.substring(6)
                    : "No encuentro el TV en " + host + ". Revisa que esté encendido, en la misma red Wi-Fi y con «LG Connect Apps» activado.");
            return;
        }
        principal = c;
        huellaPendiente = (c.esSeguro() && pin == null) ? c.huella() : null;
        reintentoSinClave = false;
        enviarRegistro();
    }

    private WsClient abrirPrincipal(String host, int port, boolean seguro, String pin, int gen) throws IOException {
        WsClient c = new WsClient(host, port, seguro, "/", pin, new WsClient.Listener() {
            @Override
            public void onText(String m) {
                if (gen == generacion) procesar(m, gen);
            }

            @Override
            public void onClose(String motivo) {
                if (gen != generacion) return;
                principal = null;
                WsClient p = puntero;
                puntero = null;
                if (p != null) p.cerrar();
                fijarEstado("desconectado", motivo);
            }
        });
        c.conectar(TIMEOUT_MS);
        return c;
    }

    private void enviarRegistro() {
        try {
            JSONObject payload = new JSONObject(leerAsset("pairing.json"));
            String clave = prefs.getString("clientKey", null);
            if (clave != null) payload.put("client-key", clave);
            JSONObject m = new JSONObject()
                    .put("type", "register")
                    .put("id", "register_0")
                    .put("payload", payload);
            principal.enviarTexto(m.toString());
        } catch (Exception e) {
            fijarEstado("error", "No se pudo enviar el registro: " + e.getMessage());
        }
    }

    private void procesar(String crudo, int gen) {
        JSONObject m;
        try {
            m = new JSONObject(crudo);
        } catch (JSONException e) {
            return;
        }
        String tipo = m.optString("type");
        String id = m.optString("id");
        JSONObject p = m.optJSONObject("payload");

        if ("register_0".equals(id)) {
            if ("registered".equals(tipo)) {
                SharedPreferences.Editor ed = prefs.edit();
                String clave = p != null ? p.optString("client-key", "") : "";
                if (!clave.isEmpty()) ed.putString("clientKey", clave);
                if (huellaPendiente != null) ed.putString("certPin", huellaPendiente);
                ed.apply();
                huellaPendiente = null;
                ultimoPedidoPuntero = 0;
                fijarEstado("conectado", ip);
                pedirSocketPuntero();
            } else if ("response".equals(tipo) && p != null && "PROMPT".equals(p.optString("pairingType"))) {
                fijarEstado("emparejando", "Acepta la solicitud que aparece en el TV");
            } else if ("error".equals(tipo)) {
                if (prefs.getString("clientKey", null) != null && !reintentoSinClave) {
                    // La clave guardada dejó de valer (TV reseteado): pedir emparejamiento nuevo
                    reintentoSinClave = true;
                    prefs.edit().remove("clientKey").apply();
                    enviarRegistro();
                } else {
                    fijarEstado("error", "El TV rechazó el emparejamiento (" + m.optString("error") + ")");
                }
            }
            return;
        }

        if ("puntero".equals(id)) {
            String ruta = p != null ? p.optString("socketPath", "") : "";
            if (!ruta.isEmpty()) io.execute(() -> abrirPuntero(ruta, gen));
            return;
        }

        if (id.startsWith("js:")) eventos.onRespuestaTv(id.substring(3), crudo);
    }

    private void pedirSocketPuntero() {
        long ahora = System.currentTimeMillis();
        if (ahora - ultimoPedidoPuntero < 3000) return;
        ultimoPedidoPuntero = ahora;
        try {
            JSONObject m = new JSONObject()
                    .put("type", "request")
                    .put("id", "puntero")
                    .put("uri", "ssap://com.webos.service.networkinput/getPointerInputSocket");
            WsClient c = principal;
            if (c != null) c.enviarTexto(m.toString());
        } catch (Exception ignored) {
        }
    }

    private void abrirPuntero(String ruta, int gen) {
        if (gen != generacion) return;
        try {
            URI u = new URI(ruta);
            boolean seguro = "wss".equalsIgnoreCase(u.getScheme());
            int port = u.getPort() > 0 ? u.getPort() : (seguro ? 3001 : 3000);
            String path = u.getRawPath();
            if (u.getRawQuery() != null) path += "?" + u.getRawQuery();
            WsClient c = new WsClient(ip, port, seguro, path, null, new WsClient.Listener() {
                @Override
                public void onText(String m) {
                }

                @Override
                public void onClose(String motivo) {
                    if (gen != generacion) return;
                    puntero = null;
                    emitirEstado();
                    WsClient pr = principal;
                    if (pr != null && pr.estaAbierto()) pedirSocketPuntero();
                }
            });
            c.conectar(TIMEOUT_MS);
            if (gen != generacion) {
                c.cerrar();
                return;
            }
            puntero = c;
            emitirEstado();
        } catch (Exception e) {
            puntero = null;
            emitirEstado();
        }
    }

    private boolean enviarPuntero(String msg) {
        WsClient p = puntero;
        if (p == null || !p.estaAbierto()) return false;
        try {
            p.enviarTexto(msg);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private void cerrarSockets() {
        WsClient p = puntero, c = principal;
        puntero = null;
        principal = null;
        if (p != null) p.cerrar();
        if (c != null) c.cerrar();
    }

    private void fijarEstado(String e, String d) {
        estado = e;
        detalle = d == null ? "" : d;
        emitirEstado();
    }

    private void emitirEstado() {
        eventos.onEstadoTv(estadoJson());
    }

    private String leerAsset(String nombre) throws IOException {
        try (InputStream is = ctx.getAssets().open(nombre)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString(StandardCharsets.UTF_8.name());
        }
    }
}
