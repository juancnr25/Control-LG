package pe.jc.remotolg;

import android.util.Base64;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Cliente WebSocket mínimo (RFC 6455) sin dependencias.
 * El TV usa un certificado autofirmado: se acepta la primera vez y luego se fija
 * su huella SHA-256 (trust on first use) para detectar si cambia.
 */
final class WsClient {

    interface Listener {
        void onText(String mensaje);

        void onClose(String motivo);
    }

    private final String host;
    private final int port;
    private final boolean seguro;
    private final String path;
    private final String huellaEsperada;
    private final Listener listener;
    private final SecureRandom rnd = new SecureRandom();

    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private volatile boolean abierto;
    private volatile boolean cerradoNotificado;
    private String huella;

    WsClient(String host, int port, boolean seguro, String path, String huellaEsperada, Listener listener) {
        this.host = host;
        this.port = port;
        this.seguro = seguro;
        this.path = path == null || path.isEmpty() ? "/" : path;
        this.huellaEsperada = huellaEsperada;
        this.listener = listener;
    }

    boolean esSeguro() {
        return seguro;
    }

    boolean estaAbierto() {
        return abierto;
    }

    String huella() {
        return huella;
    }

    /** Bloqueante: llamar fuera del hilo principal. */
    void conectar(int timeoutMs) throws IOException {
        Socket crudo = new Socket();
        try {
            crudo.connect(new InetSocketAddress(host, port), timeoutMs);
            crudo.setSoTimeout(timeoutMs);
            crudo.setTcpNoDelay(true);
            Socket s = crudo;
            if (seguro) {
                SSLSocket ssl = (SSLSocket) contextoConfiaTodo().getSocketFactory()
                        .createSocket(crudo, host, port, true);
                ssl.setSoTimeout(timeoutMs);
                ssl.startHandshake();
                Certificate[] certs = ssl.getSession().getPeerCertificates();
                try {
                    huella = sha256(certs[0].getEncoded());
                } catch (java.security.cert.CertificateEncodingException e) {
                    throw new IOException("Certificado del TV ilegible", e);
                }
                if (huellaEsperada != null && !huellaEsperada.equals(huella)) {
                    ssl.close();
                    throw new IOException("CERT: el certificado del TV cambió. Usa «Olvidar TV» y vuelve a emparejar.");
                }
                s = ssl;
            }
            socket = s;
            in = new BufferedInputStream(s.getInputStream());
            out = new BufferedOutputStream(s.getOutputStream());

            byte[] k = new byte[16];
            rnd.nextBytes(k);
            String clave = Base64.encodeToString(k, Base64.NO_WRAP);
            String req = "GET " + path + " HTTP/1.1\r\n"
                    + "Host: " + host + ":" + port + "\r\n"
                    + "Upgrade: websocket\r\n"
                    + "Connection: Upgrade\r\n"
                    + "Sec-WebSocket-Key: " + clave + "\r\n"
                    + "Sec-WebSocket-Version: 13\r\n\r\n";
            out.write(req.getBytes(StandardCharsets.US_ASCII));
            out.flush();

            String estado = leerLinea();
            if (estado == null || !estado.contains(" 101")) {
                throw new IOException("El TV no aceptó la conexión (" + estado + ")");
            }
            String linea;
            while ((linea = leerLinea()) != null && !linea.isEmpty()) {
                // cabeceras ignoradas
            }
            socket.setSoTimeout(0);
            abierto = true;
        } catch (IOException e) {
            try {
                crudo.close();
            } catch (IOException ignored) {
            }
            throw e;
        }
        Thread t = new Thread(this::bucleLectura, "ws-" + port);
        t.setDaemon(true);
        t.start();
    }

    void enviarTexto(String texto) throws IOException {
        enviarTrama(0x1, texto.getBytes(StandardCharsets.UTF_8));
    }

    void cerrar() {
        if (abierto) {
            try {
                enviarTrama(0x8, new byte[0]);
            } catch (IOException ignored) {
            }
        }
        abierto = false;
        cerrarSocket();
    }

    private String leerLinea() throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') {
                int n = sb.length();
                if (n > 0 && sb.charAt(n - 1) == '\r') sb.setLength(n - 1);
                return sb.toString();
            }
            sb.append((char) c);
            if (sb.length() > 8192) throw new IOException("Cabecera demasiado larga");
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private void bucleLectura() {
        String motivo = "Conexión cerrada";
        ByteArrayOutputStream fragmentos = new ByteArrayOutputStream();
        int opFragmento = 0;
        try {
            DataInputStream din = new DataInputStream(in);
            while (abierto) {
                int b0 = din.readUnsignedByte();
                int b1 = din.readUnsignedByte();
                boolean fin = (b0 & 0x80) != 0;
                int op = b0 & 0x0F;
                boolean conMascara = (b1 & 0x80) != 0;
                long largo = b1 & 0x7F;
                if (largo == 126) largo = din.readUnsignedShort();
                else if (largo == 127) largo = din.readLong();
                if (largo < 0 || largo > 8 * 1024 * 1024) throw new IOException("Trama inválida");
                byte[] mascara = null;
                if (conMascara) {
                    mascara = new byte[4];
                    din.readFully(mascara);
                }
                byte[] datos = new byte[(int) largo];
                din.readFully(datos);
                if (mascara != null) {
                    for (int i = 0; i < datos.length; i++) datos[i] ^= mascara[i & 3];
                }
                switch (op) {
                    case 0x0:
                        fragmentos.write(datos);
                        if (fin) {
                            entregar(opFragmento, fragmentos.toByteArray());
                            fragmentos.reset();
                        }
                        break;
                    case 0x1:
                    case 0x2:
                        if (fin) {
                            entregar(op, datos);
                        } else {
                            opFragmento = op;
                            fragmentos.reset();
                            fragmentos.write(datos);
                        }
                        break;
                    case 0x8:
                        motivo = "El TV cerró la conexión";
                        try {
                            enviarTrama(0x8, new byte[0]);
                        } catch (IOException ignored) {
                        }
                        abierto = false;
                        break;
                    case 0x9:
                        enviarTrama(0xA, datos);
                        break;
                    default:
                        break;
                }
            }
        } catch (IOException e) {
            if (abierto) motivo = "Se perdió la conexión con el TV";
        } finally {
            abierto = false;
            cerrarSocket();
            if (!cerradoNotificado) {
                cerradoNotificado = true;
                listener.onClose(motivo);
            }
        }
    }

    private void entregar(int op, byte[] datos) {
        if (op == 0x1) listener.onText(new String(datos, StandardCharsets.UTF_8));
    }

    private synchronized void enviarTrama(int op, byte[] carga) throws IOException {
        if (out == null) throw new IOException("Sin conexión");
        int n = carga.length;
        out.write(0x80 | op);
        if (n < 126) {
            out.write(0x80 | n);
        } else if (n < 65536) {
            out.write(0x80 | 126);
            out.write((n >>> 8) & 0xFF);
            out.write(n & 0xFF);
        } else {
            out.write(0x80 | 127);
            for (int i = 7; i >= 0; i--) out.write(i >= 4 ? 0 : (n >>> (8 * i)) & 0xFF);
        }
        byte[] m = new byte[4];
        rnd.nextBytes(m);
        out.write(m);
        byte[] x = new byte[n];
        for (int i = 0; i < n; i++) x[i] = (byte) (carga[i] ^ m[i & 3]);
        out.write(x);
        out.flush();
    }

    private void cerrarSocket() {
        try {
            if (socket != null) socket.close();
        } catch (IOException ignored) {
        }
    }

    private static SSLContext contextoConfiaTodo() throws IOException {
        try {
            TrustManager[] tm = {new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] c, String a) {
                }

                @Override
                public void checkServerTrusted(X509Certificate[] c, String a) {
                }

                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            }};
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, tm, new SecureRandom());
            return ctx;
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    private static String sha256(byte[] b) throws IOException {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(b);
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            throw new IOException(e);
        }
    }
}
