package pe.jc.remotolg;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Busca TVs webOS en la red local con SSDP. Devuelve pares [ip, nombre]. */
final class Descubrimiento {

    private static final String ST = "urn:lge-com:service:webos-second-screen:1";

    static List<String[]> buscar(Context ctx, int duracionMs) {
        Map<String, String> encontrados = new LinkedHashMap<>();
        WifiManager wifi = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiManager.MulticastLock lock = null;
        DatagramSocket s = null;
        try {
            if (wifi != null) {
                lock = wifi.createMulticastLock("remoto-ssdp");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            s = new DatagramSocket();
            s.setSoTimeout(300);
            String msg = "M-SEARCH * HTTP/1.1\r\n"
                    + "HOST: 239.255.255.250:1900\r\n"
                    + "MAN: \"ssdp:discover\"\r\n"
                    + "MX: 2\r\n"
                    + "ST: " + ST + "\r\n\r\n";
            byte[] b = msg.getBytes(StandardCharsets.US_ASCII);
            InetAddress grupo = InetAddress.getByName("239.255.255.250");
            long fin = System.currentTimeMillis() + duracionMs;
            long proximoEnvio = 0;
            byte[] buf = new byte[2048];
            while (System.currentTimeMillis() < fin) {
                if (System.currentTimeMillis() >= proximoEnvio) {
                    s.send(new DatagramPacket(b, b.length, grupo, 1900));
                    proximoEnvio = System.currentTimeMillis() + 800;
                }
                DatagramPacket r = new DatagramPacket(buf, buf.length);
                try {
                    s.receive(r);
                } catch (SocketTimeoutException t) {
                    continue;
                }
                String txt = new String(r.getData(), 0, r.getLength(), StandardCharsets.UTF_8);
                if (!txt.contains("lge") && !txt.contains("LG")) continue;
                String ip = r.getAddress().getHostAddress();
                String nombre = cabecera(txt, "DLNADeviceName.lge.com");
                if (nombre == null) nombre = cabecera(txt, "SERVER");
                if (nombre == null) nombre = "TV LG";
                try {
                    nombre = URLDecoder.decode(nombre, "UTF-8");
                } catch (Exception ignored) {
                }
                encontrados.put(ip, nombre);
            }
        } catch (Exception ignored) {
        } finally {
            if (s != null) s.close();
            if (lock != null && lock.isHeld()) lock.release();
        }
        List<String[]> out = new ArrayList<>();
        for (Map.Entry<String, String> e : encontrados.entrySet()) out.add(new String[]{e.getKey(), e.getValue()});
        return out;
    }

    private static String cabecera(String txt, String nombre) {
        for (String linea : txt.split("\r\n")) {
            int i = linea.indexOf(':');
            if (i > 0 && linea.substring(0, i).trim().equalsIgnoreCase(nombre)) return linea.substring(i + 1).trim();
        }
        return null;
    }
}
