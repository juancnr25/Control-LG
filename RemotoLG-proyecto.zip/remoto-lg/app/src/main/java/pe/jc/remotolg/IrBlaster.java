package pe.jc.remotolg;

import android.content.Context;
import android.hardware.ConsumerIrManager;

/**
 * Emisor infrarrojo para TV LG (protocolo NEC, dirección 0x04, portadora 38 kHz).
 * Cada comando es el byte de comando NEC: Power = 0x08, Vol+ = 0x02, etc.
 */
final class IrBlaster {
    private static final int FRECUENCIA = 38000;
    private static final int DIRECCION_LG = 0x04;

    private final ConsumerIrManager ir;
    private String ultimoError = "";

    IrBlaster(Context ctx) {
        ConsumerIrManager m = null;
        try {
            m = (ConsumerIrManager) ctx.getSystemService(Context.CONSUMER_IR_SERVICE);
        } catch (Exception ignored) {
        }
        ir = m;
    }

    boolean disponible() {
        try {
            return ir != null && ir.hasIrEmitter();
        } catch (Exception e) {
            return false;
        }
    }

    String ultimoError() {
        return ultimoError;
    }

    boolean enviar(int comando) {
        if (!disponible()) {
            ultimoError = "Este celular no reporta emisor IR";
            return false;
        }
        try {
            ir.transmit(FRECUENCIA, patronNec(DIRECCION_LG, comando));
            return true;
        } catch (Exception e) {
            ultimoError = "Falló el envío IR: " + e.getMessage();
            return false;
        }
    }

    /** Trama NEC en microsegundos: 9 ms + 4,5 ms de cabecera, 32 bits LSB primero, bit de parada. */
    static int[] patronNec(int direccion, int comando) {
        int[] p = new int[2 + 64 + 1];
        int i = 0;
        p[i++] = 9000;
        p[i++] = 4500;
        int datos = (direccion & 0xFF)
                | ((~direccion & 0xFF) << 8)
                | ((comando & 0xFF) << 16)
                | ((~comando & 0xFF) << 24);
        for (int b = 0; b < 32; b++) {
            p[i++] = 560;
            p[i++] = ((datos >>> b) & 1) == 1 ? 1690 : 560;
        }
        p[i] = 560;
        return p;
    }
}
