package pe.jc.remotolg;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends Activity implements LgTv.Eventos {

    private static final int FONDO = 0xFF121315;

    private WebView web;
    private IrBlaster ir;
    private LgTv tv;
    private SharedPreferences prefs;
    private Vibrator vibrador;
    private final ExecutorService hiloIr = Executors.newSingleThreadExecutor();
    private final ExecutorService hiloFondo = Executors.newSingleThreadExecutor();
    private final AtomicInteger irPendientes = new AtomicInteger();
    private volatile boolean volumenFisico = true;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        Window w = getWindow();
        w.setStatusBarColor(FONDO);
        w.setNavigationBarColor(FONDO);

        prefs = getSharedPreferences("remoto", MODE_PRIVATE);
        volumenFisico = prefs.getBoolean("volumenFisico", true);
        ir = new IrBlaster(this);
        vibrador = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        tv = new LgTv(this, prefs, this);

        web = new WebView(this);
        web.setBackgroundColor(FONDO);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setHapticFeedbackEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        web.setWebViewClient(new WebViewClient() {
            // Íconos de apps servidos por el TV con su certificado autofirmado: aceptar solo desde la IP del TV
            @Override
            public void onReceivedSslError(WebView v, SslErrorHandler h, SslError err) {
                String ipTv = prefs.getString("ip", "");
                String host = Uri.parse(err.getUrl()).getHost();
                if (!ipTv.isEmpty() && ipTv.equals(host)) h.proceed();
                else h.cancel();
            }
        });
        web.addJavascriptInterface(new Puente(), "Native");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override
    protected void onResume() {
        super.onResume();
        emitir("reanudar", "{}");
    }

    @Override
    protected void onDestroy() {
        tv.desconectar();
        web.destroy();
        super.onDestroy();
    }

    /** Los botones de volumen del celular controlan el TV. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (volumenFisico && (k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if (e.getAction() == KeyEvent.ACTION_DOWN) {
                emitir("teclaFisica", JSONObject.quote(k == KeyEvent.KEYCODE_VOLUME_UP ? "volUp" : "volDown"));
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    private void emitir(String evento, String json) {
        final String js = "window.onNative&&window.onNative(" + JSONObject.quote(evento) + "," + json + ")";
        if (web != null) web.post(() -> web.evaluateJavascript(js, null));
    }

    @Override
    public void onEstadoTv(String json) {
        emitir("tv", json);
    }

    @Override
    public void onRespuestaTv(String id, String json) {
        emitir("respuesta", "{\"id\":" + JSONObject.quote(id) + ",\"msg\":" + json + "}");
    }

    final class Puente {
        @JavascriptInterface
        public boolean tieneIr() {
            return ir.disponible();
        }

        @JavascriptInterface
        public void ir(int comando) {
            if (irPendientes.get() > 2) return; // evita cola acumulada al mantener presionado
            irPendientes.incrementAndGet();
            hiloIr.execute(() -> {
                boolean ok = ir.enviar(comando);
                irPendientes.decrementAndGet();
                if (!ok) emitir("errorIr", JSONObject.quote(ir.ultimoError()));
            });
        }

        @JavascriptInterface
        public void vibrar(int ms) {
            if (vibrador == null || !vibrador.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) {
                vibrador.vibrate(VibrationEffect.createOneShot(Math.max(5, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrador.vibrate(Math.max(5, ms));
            }
        }

        @JavascriptInterface
        public void conectar(String ip) {
            tv.conectar(ip);
        }

        @JavascriptInterface
        public void desconectar() {
            tv.desconectar();
        }

        @JavascriptInterface
        public void olvidar() {
            tv.olvidar();
        }

        @JavascriptInterface
        public String estadoTv() {
            return tv.estadoJson();
        }

        @JavascriptInterface
        public boolean boton(String nombre) {
            return tv.boton(nombre);
        }

        @JavascriptInterface
        public boolean solicitar(String id, String uri, String payload) {
            return tv.solicitar(id, uri, payload);
        }

        @JavascriptInterface
        public boolean mover(int dx, int dy) {
            return tv.mover(dx, dy);
        }

        @JavascriptInterface
        public boolean clic() {
            return tv.clic();
        }

        @JavascriptInterface
        public boolean desplazar(int dy) {
            return tv.desplazar(dy);
        }

        @JavascriptInterface
        public void buscarTv() {
            hiloFondo.execute(() -> {
                List<String[]> r = Descubrimiento.buscar(getApplicationContext(), 3000);
                JSONArray a = new JSONArray();
                for (String[] x : r) {
                    try {
                        a.put(new JSONObject().put("ip", x[0]).put("nombre", x[1]));
                    } catch (Exception ignored) {
                    }
                }
                emitir("tvEncontrados", a.toString());
            });
        }

        @JavascriptInterface
        public String leer(String clave) {
            return prefs.getString("ui_" + clave, null);
        }

        @JavascriptInterface
        public void guardar(String clave, String valor) {
            prefs.edit().putString("ui_" + clave, valor).apply();
        }

        @JavascriptInterface
        public void volumenFisico(boolean activo) {
            volumenFisico = activo;
            prefs.edit().putBoolean("volumenFisico", activo).apply();
        }

        @JavascriptInterface
        public String version() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }
    }
}
